
Dec 28, 1999  1:00am

C99 Cross-assembler Readme File

This program has compiled successfully in
    Sun/Solaris
    Power-C (MS-DOS 8086 system)
    Microsoft Visual C 1.0 (Windows 95 80586 system)

Files that should accompany this Readme:
     dosopts.txt      Compilation Instructions for DOS systems
     unixopts.txt     Compilation Instructions for UNIX/LINUX systems

  Source Files
     c99c0.c
     c99c1.c
     c99c2.c
     c99c3.c
     c99csb.c
     myfuncs.c

  Header Files
     c99.h
     c99proto.h
     myfuncs.h

     This isn't a "pretty" code; I just took a source code I found on the Internet and made it work with my computer, and made it "make sense" to me.  The code is made available "as-is", with no warrantee.  User assumes all risks of use.  The code is made available in the spirit of keeping the Texas Instruments 99/4A computer alive through making the process of generating programs easier, using a MS-DOS or UNIX/LINUX system.  All copyrights are property of their respective owners, etc.  Good Luck.

Kristine Rogers
